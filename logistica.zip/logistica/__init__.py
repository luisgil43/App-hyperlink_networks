default_app_config = 'logistica.apps.LogisticaConfig'
